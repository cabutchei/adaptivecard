# adaptivecard
Small library designed to help you easily generate json-formatted cards
